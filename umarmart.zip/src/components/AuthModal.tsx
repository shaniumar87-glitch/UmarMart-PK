import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  User as UserIcon,
  Lock,
  Mail,
  Sparkles,
  Eye,
  EyeOff,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Smartphone,
  RefreshCw,
  KeyRound,
  Check
} from 'lucide-react';
import { User } from '../types';
import { DEMO_USER } from '../data/mockData';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string) => void;
  onLoginSuccess: (user: User) => void;
}

type AuthMode = 'signin' | 'signup' | 'forgot_password' | 'otp_verify' | 'reset_new_password';

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onShowToast,
  onLoginSuccess,
}) => {
  const [authMode, setAuthMode] = useState<AuthMode>('signin');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('+92 315 2643791');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // OTP state
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [otpResendTimer, setOtpResendTimer] = useState(45);
  const [otpPurpose, setOtpPurpose] = useState<'signup' | 'reset' | 'email_verify'>('signup');

  // Resend OTP countdown timer effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (authMode === 'otp_verify' && otpResendTimer > 0) {
      timer = setInterval(() => {
        setOtpResendTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [authMode, otpResendTimer]);

  if (!isOpen) return null;

  // Password strength logic
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { level: 0, text: '' };
    if (pass.length < 6) return { level: 1, text: 'Weak', color: 'bg-rose-500' };
    if (pass.length < 10) return { level: 2, text: 'Medium', color: 'bg-amber-500' };
    return { level: 3, text: 'Strong VIP Standard', color: 'bg-emerald-500' };
  };

  const strength = getPasswordStrength(password);

  const handleOtpInputChange = (index: number, val: string) => {
    if (!/^\d*$/.test(val)) return;
    const copy = [...otpDigits];
    copy[index] = val.slice(-1);
    setOtpDigits(copy);

    // Auto-advance focus to next field
    if (val && index < 5) {
      const nextInput = document.getElementById(`otp-input-${index + 1}`);
      if (nextInput) nextInput.focus();
    }
  };

  const handleAutoFillDemoOtp = () => {
    setOtpDigits(['4', '8', '2', '1', '9', '5']);
    onShowToast('Auto-filled OTP: 482195');
  };

  const handleResendOtp = () => {
    setOtpResendTimer(45);
    onShowToast(`New 6-digit OTP code sent to ${email || phone}`);
  };

  const handleInitiateSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      onShowToast('Please fill all required fields');
      return;
    }
    setOtpPurpose('signup');
    setOtpResendTimer(45);
    setAuthMode('otp_verify');
    onShowToast(`Verification code sent to ${email}`);
  };

  const handleInitiateForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      onShowToast('Please enter your registered email');
      return;
    }
    setOtpPurpose('reset');
    setOtpResendTimer(45);
    setAuthMode('otp_verify');
    onShowToast(`Password recovery OTP code sent to ${email}`);
  };

  const handleVerifyOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const enteredOtp = otpDigits.join('');
    if (enteredOtp.length < 6) {
      onShowToast('Please enter all 6 digits of the OTP code');
      return;
    }

    if (otpPurpose === 'signup') {
      const newUser: User = {
        ...DEMO_USER,
        id: 'usr-' + Date.now(),
        name: name.trim() || 'UmarMart VIP Member',
        email: email.trim() || 'member@umarmart.pk',
        phone: phone.trim() || '+92 315 2643791',
        isEmailVerified: true,
        joinedDate: 'Just now',
      };
      onLoginSuccess(newUser);
      onShowToast(`🎉 Account created & Email verified! Welcome, ${newUser.name}!`);
      onClose();
    } else if (otpPurpose === 'reset') {
      setAuthMode('reset_new_password');
      onShowToast('OTP verified! Enter your new password.');
    }
  };

  const handleSetNewPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      onShowToast('Password must be at least 6 characters');
      return;
    }
    const user: User = {
      ...DEMO_USER,
      email: email.trim() || DEMO_USER.email,
    };
    onLoginSuccess(user);
    onShowToast('🔑 Password reset successfully! You are now logged in.');
    onClose();
  };

  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const user: User = {
      ...DEMO_USER,
      name: name.trim() || DEMO_USER.name,
      email: email.trim() || DEMO_USER.email,
    };
    onLoginSuccess(user);
    onShowToast(`Welcome back, ${user.name}!`);
    onClose();
  };

  const handleDemoSignIn = () => {
    onLoginSuccess(DEMO_USER);
    onShowToast(`Signed in as Demo VIP: ${DEMO_USER.name}`);
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2 }}
          className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 sm:p-8 relative shadow-2xl space-y-6 text-slate-900 my-8 overflow-hidden"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Modal Header */}
          <div className="text-center space-y-2 pt-2">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mx-auto shadow-sm">
              {authMode === 'otp_verify' ? (
                <ShieldCheck className="w-6 h-6 text-emerald-600" />
              ) : authMode === 'reset_new_password' ? (
                <KeyRound className="w-6 h-6 text-blue-600" />
              ) : (
                <UserIcon className="w-6 h-6 text-blue-600" />
              )}
            </div>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">
              {authMode === 'signin' && 'Sign In to UmarMart'}
              {authMode === 'signup' && 'Create VIP Account'}
              {authMode === 'forgot_password' && 'Reset Password'}
              {authMode === 'otp_verify' && 'Verify OTP Code'}
              {authMode === 'reset_new_password' && 'Set New Password'}
            </h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              {authMode === 'signin' && 'Access your order history, saved addresses, and VIP rewards'}
              {authMode === 'signup' && 'Register now for instant VIP perks and express checkout'}
              {authMode === 'forgot_password' && 'Enter your email or mobile number for a 6-digit verification code'}
              {authMode === 'otp_verify' && `We sent a 6-digit code to ${email || phone}`}
              {authMode === 'reset_new_password' && 'Enter a secure new password for your account'}
            </p>
          </div>

          {/* 1-Click Demo Login Bar (Visible on Signin & Signup) */}
          {(authMode === 'signin' || authMode === 'signup') && (
            <button
              onClick={handleDemoSignIn}
              type="button"
              className="w-full bg-gradient-to-r from-blue-50 via-indigo-50 to-blue-50 border border-blue-200 hover:border-blue-300 text-blue-700 p-3 rounded-2xl flex items-center justify-between text-xs font-bold transition-all shadow-sm group"
            >
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                <span>1-Click Demo VIP Login ({DEMO_USER.name})</span>
              </div>
              <ArrowRight className="w-4 h-4 text-blue-600 group-hover:translate-x-0.5 transition-transform" />
            </button>
          )}

          {/* Divider */}
          {(authMode === 'signin' || authMode === 'signup') && (
            <div className="relative flex items-center justify-center">
              <div className="border-t border-slate-200 w-full" />
              <span className="bg-white px-3 text-[10px] font-bold uppercase text-slate-400 shrink-0">
                {authMode === 'signin' ? 'or sign in with email' : 'or register with email & phone'}
              </span>
            </div>
          )}

          {/* --- SIGN IN FORM --- */}
          {authMode === 'signin' && (
            <form onSubmit={handleSignInSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email or Phone</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="shaniumar87@gmail.com"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">Password</label>
                  <button
                    type="button"
                    onClick={() => setAuthMode('forgot_password')}
                    className="text-[11px] text-blue-600 font-bold hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-10 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-full shadow-md shadow-blue-600/20 text-xs transition-all flex items-center justify-center space-x-2"
              >
                <span>Sign In to UmarMart</span>
              </button>
            </form>
          )}

          {/* --- SIGN UP FORM --- */}
          {authMode === 'signup' && (
            <form onSubmit={handleInitiateSignup} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Umar Shani"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="shaniumar87@gmail.com"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Phone (+92 Pakistan)</label>
                <div className="relative">
                  <Smartphone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+92 315 2643791"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-10 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {password && (
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center justify-between text-[10px] text-slate-500 font-bold">
                      <span>Password Strength</span>
                      <span className="text-slate-700">{strength.text}</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden flex">
                      <div
                        className={`h-full ${strength.color} transition-all duration-300`}
                        style={{ width: `${(strength.level / 3) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-full shadow-md shadow-blue-600/20 text-xs transition-all flex items-center justify-center space-x-2"
              >
                <span>Continue & Send OTP Code →</span>
              </button>
            </form>
          )}

          {/* --- FORGOT PASSWORD FORM --- */}
          {authMode === 'forgot_password' && (
            <form onSubmit={handleInitiateForgotPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Registered Email or Phone</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="shaniumar87@gmail.com"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-full shadow-md shadow-blue-600/20 text-xs transition-all flex items-center justify-center space-x-2"
              >
                <span>Send Password Reset OTP</span>
              </button>
            </form>
          )}

          {/* --- OTP VERIFICATION FORM --- */}
          {authMode === 'otp_verify' && (
            <form onSubmit={handleVerifyOtpSubmit} className="space-y-5">
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 text-center space-y-1 text-emerald-950 text-xs">
                <span className="font-bold flex items-center justify-center gap-1 text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  6-Digit Verification Code Dispatched
                </span>
                <p className="text-[11px] text-emerald-700">
                  Please enter the code sent to <strong>{email || phone}</strong>.
                </p>
              </div>

              {/* OTP Digits Grid */}
              <div className="flex justify-between gap-2">
                {otpDigits.map((digit, idx) => (
                  <input
                    key={idx}
                    id={`otp-input-${idx}`}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpInputChange(idx, e.target.value)}
                    className="w-11 h-12 text-center text-lg font-black text-slate-900 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:border-emerald-600 focus:bg-white shadow-xs"
                  />
                ))}
              </div>

              {/* Quick Auto-Fill Demo OTP Button */}
              <div className="flex items-center justify-between text-xs pt-1">
                <button
                  type="button"
                  onClick={handleAutoFillDemoOtp}
                  className="text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 font-bold px-3 py-1 rounded-lg text-[11px] transition-colors"
                >
                  ⚡ Auto-fill Code (482195)
                </button>

                {otpResendTimer > 0 ? (
                  <span className="text-[11px] font-semibold text-slate-400">
                    Resend code in {otpResendTimer}s
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={handleResendOtp}
                    className="text-blue-600 font-bold text-[11px] hover:underline flex items-center space-x-1"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Resend OTP</span>
                  </button>
                )}
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-full shadow-md shadow-emerald-600/20 text-xs transition-all flex items-center justify-center space-x-2"
              >
                <Check className="w-4 h-4" />
                <span>Verify OTP & Continue</span>
              </button>
            </form>
          )}

          {/* --- SET NEW PASSWORD FORM --- */}
          {authMode === 'reset_new_password' && (
            <form onSubmit={handleSetNewPasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">New Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password (min 6 chars)"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-full shadow-md shadow-blue-600/20 text-xs transition-all flex items-center justify-center space-x-2"
              >
                <span>Save New Password & Sign In</span>
              </button>
            </form>
          )}

          {/* Bottom toggle options */}
          <div className="text-center text-xs text-slate-500 border-t border-slate-100 pt-4">
            {authMode === 'signin' && (
              <div>
                <span>Don't have a VIP account?</span>{' '}
                <button
                  onClick={() => setAuthMode('signup')}
                  className="text-blue-600 font-bold hover:underline"
                >
                  Register VIP Account
                </button>
              </div>
            )}

            {authMode === 'signup' && (
              <div>
                <span>Already registered?</span>{' '}
                <button
                  onClick={() => setAuthMode('signin')}
                  className="text-blue-600 font-bold hover:underline"
                >
                  Sign In
                </button>
              </div>
            )}

            {(authMode === 'forgot_password' || authMode === 'otp_verify' || authMode === 'reset_new_password') && (
              <button
                onClick={() => setAuthMode('signin')}
                className="text-blue-600 font-bold hover:underline"
              >
                ← Back to Sign In
              </button>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

