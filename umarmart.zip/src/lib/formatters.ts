import { Currency } from '../types';

export function formatPrice(amountInBasePKR: number, currency: Currency): string {
  const converted = amountInBasePKR * currency.rate;
  
  if (currency.code === 'PKR') {
    return `${currency.symbol}${Math.round(converted).toLocaleString('en-PK')}`;
  }
  if (currency.code === 'AED') {
    return `${currency.symbol}${converted.toFixed(2)}`;
  }
  return `${currency.symbol}${converted.toFixed(2)}`;
}

export function calculateDiscount(price: number, originalPrice?: number): number {
  if (!originalPrice || originalPrice <= price) return 0;
  return Math.round(((originalPrice - price) / originalPrice) * 100);
}

export function formatTimeLeft(targetDate: string): { hours: number; minutes: number; seconds: number } {
  const total = Date.parse(targetDate) - Date.parse(new Date().toString());
  if (total <= 0) return { hours: 0, minutes: 0, seconds: 0 };
  
  const seconds = Math.floor((total / 1000) % 60);
  const minutes = Math.floor((total / 1000 / 60) % 60);
  const hours = Math.floor((total / (1000 * 60 * 60)));
  
  return { hours, minutes, seconds };
}
